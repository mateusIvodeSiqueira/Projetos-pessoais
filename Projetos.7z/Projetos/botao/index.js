    let i = 0;
    let j = 0;
    let textos = ["APERTE O BOTÃO","Tenta novamente", "Mais uma vez...", "Vai vc consegue!!", "Não é tão dificil"];

    const text = document.querySelector("#texto");
    const area = document.querySelector(".campo");
    const corre = document.querySelector("#foge");
    const container = document.querySelector(".container");
    const conta = document.querySelector("#cont");
    const btn = document.querySelector("#atchu");

    corre.addEventListener('click', function(e){
        e.preventDefault();
        j++;
        i++;
        if(i>4){
            i=0;
        }
        trocaTexto(i);
        geraXY();
        setTimeout(() => {
            corre.blur();
        }, 10);
        
    });
    function trocaTexto(a){
        
        text.innerHTML = textos[a];
    }

   conta.addEventListener('click', function(e){
    e.preventDefault();
    btn.innerHTML = `Ele fugiu ${j} vezes`;
   });

    function geraXY(){
        
        let minX = Math.floor(-area.clientWidth/2)+corre.clientWidth/2;
        let minY = Math.floor(-area.clientHeight/2)+corre.clientHeight;
        let maxX = Math.floor(area.clientWidth/2)-corre.clientWidth/2;
        let maxY = Math.floor(area.clientHeight/2)-corre.clientHeight;
        
        let X = Math.floor(Math.random()*(maxX-minX+1))+minX;
        let Y = Math.floor(Math.random()*(maxY-minY+1))+minY;
        corre.style.transform = `translate(${X}px, ${Y}px)`;
        console.log(`minX ${minX}`);
        console.log(`maxX ${maxX}`);
        console.log(`maxY ${maxY}`);
        console.log(`minY ${minY}`);
        console.log(`Numero gerado aleatóriamenteX: ${X}`);
        console.log(`Numero gerado aleatóriamenteY ${Y}`);
        console.log(`Repetições ${i}`);
        console.log(`J ${j}`);
        conta.style.display = "block";
    }
    

            
